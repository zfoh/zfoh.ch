module Main where

import qualified Language.Stitch.Repl as Repl ( main )

main :: IO ()
main = Repl.main
