{-# LANGUAGE TypeInType, ExplicitForAll, TypeOperators, GADTs,
             MultiParamTypeClasses, FlexibleContexts, RankNTypes,
             TypeFamilies, TypeApplications, TupleSections,
             DeriveFunctor, GeneralizedNewtypeDeriving, FlexibleInstances,
             UndecidableInstances, ScopedTypeVariables, AllowAmbiguousTypes #-}

module Language.Stitch.IExp where

import Data.Kind
import Data.Type.Equality

import Language.Stitch.Type

import Language.Stitch.Data.Nat
import Language.Stitch.Data.Vec
import Language.Stitch.Globals
import Language.Stitch.Unchecked
import Language.Stitch.Data.Singletons
import Language.Stitch.Data.Fin
import Language.Stitch.Data.Exists
import Language.Stitch.Control.Monad.HReader

import Text.PrettyPrint.ANSI.Leijen
import Control.Monad.Except
import Control.Monad.Reader

data IType :: Nat -> Type where
  ITyVar :: Fin m -> IType m
  IInt   :: IType m
  IBool  :: IType m
  (:~>)  :: IType m -> IType m -> IType m
infixr 0 :~>

type family WeakenFin (n :: Nat) (f :: Fin m) :: Fin (m + n) where
  WeakenFin _ FZ = FZ
  WeakenFin n (FS f) = FS (WeakenFin n f)

type family WeakenIType n (ty :: IType m) :: IType (m + n) where
  WeakenIType n (ITyVar f) = ITyVar (WeakenFin n f)
  WeakenIType _ IInt       = IInt
  WeakenIType _ IBool      = IBool
  WeakenIType n (a :~> r)  = WeakenIType n a :~> WeakenIType n r

data SFin :: forall n. Fin n -> Type where
  SFZ :: SFin FZ
  SFS :: SFin f -> SFin (FS f)

instance SingKind (Fin n) where
  type Sing = SFin

  fromSing SFZ = FZ
  fromSing (SFS f) = FS (fromSing f)

weakenSFin :: forall n f. SFin f -> SFin (WeakenFin n f)
weakenSFin SFZ = SFZ
weakenSFin (SFS f) = SFS (weakenSFin @n f)

data SIType :: IType m -> Type where
  SITyVar :: SFin f -> SIType (ITyVar f)
  SIInt   :: SIType IInt
  SIBool  :: SIType IBool
  (:%~>)  :: SIType arg -> SIType res -> SIType (arg :~> res)
infixr 0 :%~>

instance SingKind (IType m) where
  type Sing = SIType

  fromSing (SITyVar f) = ITyVar (fromSing f)
  fromSing SIInt       = IInt
  fromSing SIBool      = IBool
  fromSing (a :%~> r)  = fromSing a :~> fromSing r

type family ToIType t where
  ToIType Int      = IInt
  ToIType Bool     = IBool
  ToIType (a -> r) = ToIType a :~> ToIType r

toIType :: TypeRep t -> SIType (ToIType t)
toIType (a :-> r) = toIType a :%~> toIType r
toIType ty
  | Just HRefl <- isTypeRep @Int ty  = SIInt
  | Just HRefl <- isTypeRep @Bool ty = SIBool
  | otherwise                        = error "non-Stitch type"

weakenSIType :: forall n t. SIType t -> SIType (WeakenIType n t)
weakenSIType (SITyVar tv) = SITyVar (weakenSFin @n tv)
weakenSIType SIInt = SIInt
weakenSIType SIBool = SIBool
weakenSIType (a :%~> r) = weakenSIType @n a :%~> weakenSIType @n r

type family WeakenICtx (n :: Nat) (ctx :: ICtx m n') :: ICtx (m + n) n' where
  WeakenICtx _ VNil = VNil
  WeakenICtx n (h :> t) = WeakenIType n h :> WeakenICtx n t

weakenSCtx :: forall n ctx. Sing ctx -> Sing (WeakenICtx n ctx)
weakenSCtx SVNil = SVNil
weakenSCtx (h :%> t) = weakenSIType @n h :%> weakenSCtx @n t

type ICtx m n = Vec (IType m) n

class ctx0 <<~ ctx1

data IExp (m :: Nat) :: forall n. ICtx m n -> IType m -> Type where
  IVar :: Elem ctx ty -> IExp m ctx ty
  ILam :: SIType arg_ty -> IExp m (arg_ty :> ctx) res_ty -> IExp m ctx (arg_ty :~> res_ty)
  IApp :: (ctx0 <<~ ctx) => IExp m ctx0 (arg_ty :~> res_ty) -> IExp (m + n) ctx (WeakenIType n arg_ty) -> IExp (m + n) ctx (WeakenIType n res_ty)

newtype InferT :: Nat -> (Type -> Type) -> Type -> Type where
  InferT :: { runInferT :: SNat n -> m a } -> InferT n m a

instance Functor m => Functor (InferT n m) where
  fmap f i = InferT $ \ sn -> fmap f (runInferT i sn)

instance Applicative m => Applicative (InferT n m) where
  pure x = InferT $ \ _ -> pure x
  mf <*> ma = InferT $ \ sn -> runInferT mf sn <*> runInferT ma sn

instance Monad m => Monad (InferT n m) where
  ma >>= fmb = InferT $ \ sn -> do a <- runInferT ma sn
                                   runInferT (fmb a) sn

instance MonadReader r m => MonadReader r (InferT n m) where
  ask = InferT $ const ask
  local f i = InferT $ \ sn -> local f (runInferT i sn)

instance MonadTrans (InferT n) where
  lift action = InferT $ const action

type family TopFin n :: Fin (Succ n) where
  TopFin Zero     = FZ
  TopFin (Succ n) = FS (TopFin n)

topSFin :: SingI n => SFin (TopFin n)
topSFin = go sing
  where
    go :: SNat (Succ n) -> SFin (TopFin n)
    go (SSucc SZero)       = SFZ
    go (SSucc n@(SSucc _)) = SFS (go n)

fresh :: (forall (f :: Fin (Succ n)). SFin f -> InferT (Succ n) m a) -> InferT n m a
fresh k = InferT $ \ sn -> withSingI sn $ runInferT (k topSFin) (SSucc sn)

infer :: (MonadError Doc m, MonadReader Globals m)
      => UExp Zero -> (forall t. SIType t -> IExp Zero VNil t -> m r)
      -> m r
infer uexp k0 = runInferT (go SVNil uexp $ \ ty iexp -> lift (k0 ty iexp)) SZero

  where
    go :: (MonadError Doc monad, MonadReader Globals monad, SingI n)
       => Sing (ctx :: ICtx m n) -> UExp n -> (forall t. SIType t -> IExp m ctx t -> InferT m monad r)
       -> InferT m monad r

    go ctx (UVar n) k
      = check_var n ctx $ \ ty elem ->
        k ty (IVar elem)
      where
        check_var :: Fin n -> Sing (ctx :: ICtx m n)
                  -> (forall t. SIType t -> Elem ctx t -> monad r)
                  -> monad r
        check_var FZ     (ty :%> _)   k = k ty EZ
        check_var (FS n) (_  :%> ctx) k = check_var n ctx $ \ty elem ->
                                          k ty (ES elem)

    go ctx (ULam (Just ty) body) k
      = unpackEx ty $ \ arg_ty ->
        let iarg_ty = toIType arg_ty in
        go (iarg_ty :%> ctx) body $ \ res_ty body' ->
        k (iarg_ty :%~> res_ty) (ILam iarg_ty body')

    go ctx (ULam Nothing body) k
      = fresh $ \ tv ->
        let iarg_ty = SITyVar tv in
        go (iarg_ty :%> weakenSCtx @(Succ Zero) ctx) body $ \ res_ty body' ->
        k (iarg_ty :%~> res_ty) (ILam iarg_ty body')
